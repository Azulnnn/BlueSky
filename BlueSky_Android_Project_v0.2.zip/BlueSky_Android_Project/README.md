# BlueSky Android v0.2

Proyecto Android completo que empaqueta la primera versión funcional de BlueSky dentro de una app Android.

## Requisitos
- Android Studio reciente
- Android SDK 35
- JDK 17

## Abrir
1. Descomprime este proyecto.
2. Abre la carpeta `BlueSky_Android_Project` desde Android Studio.
3. Espera a que Gradle sincronice.
4. Ve a **Build > Build APK(s)**.
5. El APK aparecerá en:
   `app/build/outputs/apk/debug/app-debug.apk`

## Funciones incluidas
Terrario, agua, sol, crecimiento, XP, niveles, rachas, hábitos, colección, Fitness & Yoga, recetas, diario y consejos. Los datos se almacenan localmente.

## Nota
El proyecto usa un WebView local: no necesita publicar la app en Play Store.
